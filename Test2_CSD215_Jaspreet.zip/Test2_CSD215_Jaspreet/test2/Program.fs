﻿// Define discriminated union for filmsGenres
type filmsGenre =
    | Horror
    | Drama
    | Thriller
    | Comedy
    | Fantasy
    | Sport

// Define record type for directorfilms
type directorfilms = {
    Name: string
    filmss: int
}

// Define record type for films
type films = {
    Name: string
    RunLength: int
    filmsGenre: filmsGenre
    directorfilms: directorfilms
    IMDBRating: float
}

// Create films instances
let filmss = [
    { Name = "CODA"; RunLength = 111; filmsGenre = Drama; directorfilms = { Name = "Sian Heder"; filmss = 9 }; IMDBRating = 8.1 }
    { Name = "Belfast"; RunLength = 98; filmsGenre = Comedy; directorfilms = { Name = "Kenneth Branagh"; filmss = 23 }; IMDBRating = 7.3 }
    { Name = "Don't Look Up"; RunLength = 138; filmsGenre = Comedy; directorfilms = { Name = "Adam McKay"; filmss = 27 }; IMDBRating = 7.2 }
    { Name = "Drive My Car"; RunLength = 179; filmsGenre = Drama; directorfilms = { Name = "Ryusuke Hamaguchi"; filmss = 16 }; IMDBRating = 7.6 }
    { Name = "Dune"; RunLength = 155; filmsGenre = Fantasy; directorfilms = { Name = "Denis Villeneuve"; filmss = 24 }; IMDBRating = 8.1 }
    { Name = "King Richard"; RunLength = 144; filmsGenre = Sport; directorfilms = { Name = "Reinaldo Marcus Green"; filmss = 15 }; IMDBRating = 7.5 }
    { Name = "Licorice Pizza"; RunLength = 133; filmsGenre = Comedy; directorfilms = { Name = "Paul Thomas Anderson"; filmss = 49 }; IMDBRating = 7.4 }
    { Name = "Nightmare Alley"; RunLength = 150; filmsGenre = Thriller; directorfilms = { Name = "Guillermo Del Toro"; filmss = 22 }; IMDBRating = 7.1 }
]

// Identify probable Oscar winners
let winnerProbability = List.filter (fun films -> films.IMDBRating > 7.4) filmss

// Convert films run length to hours and minutes format
let runLengthConversion runLength =
    let hours = runLength / 60
    let minutes = runLength % 60
    sprintf "%dh %dmin" hours minutes

let convertedTimings = List.map (fun films -> runLengthConversion films.RunLength) filmss

// Print probable winners and converted run lengths
printfn "Probable Oscar Winners:"
winnerProbability |> List.iter (fun films -> printfn "%s" films.Name)
printfn "\nConverted Run Lengths:"
convertedTimings |> List.iter (printfn "%s")